// Simple API key sent with every Appointment request (checked by the guard)
const API_KEY = "hospital-secret-key";

const headers = {
  "Content-Type": "application/json",
  "x-api-key": API_KEY,
};

const appointmentForm = document.getElementById("appointmentForm");
const doctorForm = document.getElementById("doctorForm");
const doctorSelect = document.getElementById("doctorId");
const tableBody = document.getElementById("appointmentBody");
const emptyState = document.getElementById("emptyState");
const alertBox = document.getElementById("alertBox");

// ---------- helpers ----------
function showAlert(message, type = "danger") {
  alertBox.className = `alert alert-${type}`;
  alertBox.textContent = message;
}

function hideAlert() {
  alertBox.className = "alert d-none";
}

// Nest returns message as a string or an array of strings
async function readError(res) {
  try {
    const body = await res.json();
    return Array.isArray(body.message) ? body.message.join(", ") : body.message;
  } catch {
    return "Something went wrong";
  }
}

// ---------- API calls (async/await) ----------
async function loadDoctors() {
  const res = await fetch("/doctors");
  const doctors = await res.json();

  doctorSelect.innerHTML = '<option value="">Select a doctor</option>';
  doctors.forEach(({ id, name, specialization }) => {
    const option = document.createElement("option");
    option.value = id;
    option.textContent = `${name} (${specialization})`;
    doctorSelect.appendChild(option);
  });
}

async function loadAppointments() {
  const res = await fetch("/appointments", { headers });
  if (!res.ok) {
    showAlert(await readError(res));
    return;
  }
  renderAppointments(await res.json());
}

// ---------- rendering (DOM manipulation) ----------
function renderAppointments(appointments) {
  tableBody.innerHTML = "";

  appointments.forEach(({ id, patientName, date, reason, doctor }, index) => {
    const row = document.createElement("tr");

    const values = [
      index + 1,
      patientName,
      doctor ? doctor.name : "Unknown",
      new Date(date).toLocaleString(),
      reason || "-",
    ];
    values.forEach((value) => {
      const td = document.createElement("td");
      td.textContent = value;
      row.appendChild(td);
    });

    const actionTd = document.createElement("td");
    actionTd.className = "text-end";
    const delBtn = document.createElement("button");
    delBtn.className = "btn btn-sm btn-outline-danger";
    delBtn.textContent = "Cancel";
    delBtn.addEventListener("click", () => deleteAppointment(id));
    actionTd.appendChild(delBtn);
    row.appendChild(actionTd);

    tableBody.appendChild(row);
  });

  emptyState.classList.toggle("d-none", appointments.length > 0);
}

// ---------- events ----------
appointmentForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  hideAlert();

  const patientName = document.getElementById("patientName").value.trim();
  const doctorId = doctorSelect.value;
  const dateValue = document.getElementById("date").value;
  const reason = document.getElementById("reason").value.trim();

  // Client-side validation
  if (!patientName || !doctorId || !dateValue) {
    showAlert("Patient name, doctor and date are required.");
    return;
  }
  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) {
    showAlert("Please enter a valid date.");
    return;
  }

  const payload = {
    patientName,
    doctorId: Number(doctorId),
    date: date.toISOString(),
  };
  if (reason) payload.reason = reason;

  try {
    const res = await fetch("/appointments", {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      showAlert(await readError(res));
      return;
    }
    appointmentForm.reset();
    showAlert("Appointment booked.", "success");
    await loadAppointments();
  } catch (err) {
    showAlert("Could not reach the server.");
  }
});

doctorForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  hideAlert();

  const name = document.getElementById("doctorName").value.trim();
  const specialization = document.getElementById("specialization").value.trim();

  if (!name || !specialization) {
    showAlert("Doctor name and specialization are required.");
    return;
  }

  try {
    const res = await fetch("/doctors", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, specialization }),
    });
    if (!res.ok) {
      showAlert(await readError(res));
      return;
    }
    doctorForm.reset();
    showAlert("Doctor added.", "success");
    await loadDoctors();
  } catch (err) {
    showAlert("Could not reach the server.");
  }
});

async function deleteAppointment(id) {
  hideAlert();
  try {
    const res = await fetch(`/appointments/${id}`, {
      method: "DELETE",
      headers,
    });
    if (!res.ok) {
      showAlert(await readError(res));
      return;
    }
    await loadAppointments();
  } catch (err) {
    showAlert("Could not reach the server.");
  }
}

// ---------- init ----------
(async function init() {
  try {
    await loadDoctors();
    await loadAppointments();
  } catch (err) {
    showAlert("Could not reach the server. Is it running?");
  }
})();
