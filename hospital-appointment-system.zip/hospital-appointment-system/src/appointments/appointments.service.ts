import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Appointment } from './appointment.entity';
import { Doctor } from '../doctors/doctor.entity';
import { CreateAppointmentDto } from './dto/create-appointment.dto';
import { UpdateAppointmentDto } from './dto/update-appointment.dto';

@Injectable()
export class AppointmentsService {
  // Dependency Injection: Nest supplies both repositories
  constructor(
    @InjectRepository(Appointment)
    private readonly appointmentRepo: Repository<Appointment>,
    @InjectRepository(Doctor)
    private readonly doctorRepo: Repository<Doctor>,
  ) {}

  private async ensureDoctorExists(id: number) {
    const doctor = await this.doctorRepo.findOne({ where: { id } });
    if (!doctor) throw new NotFoundException(`Doctor ${id} not found`);
  }

  findAll(): Promise<Appointment[]> {
    return this.appointmentRepo.find({
      relations: ['doctor'],
      order: { date: 'ASC' },
    });
  }

  async findOne(id: number): Promise<Appointment> {
    const appointment = await this.appointmentRepo.findOne({
      where: { id },
      relations: ['doctor'],
    });
    if (!appointment) throw new NotFoundException(`Appointment ${id} not found`);
    return appointment;
  }

  async create(dto: CreateAppointmentDto): Promise<Appointment> {
    await this.ensureDoctorExists(dto.doctorId);
    const appointment = this.appointmentRepo.create({
      ...dto,
      date: new Date(dto.date),
    });
    const saved = await this.appointmentRepo.save(appointment);
    return this.findOne(saved.id);
  }

  async update(id: number, dto: UpdateAppointmentDto): Promise<Appointment> {
    const appointment = await this.findOne(id);
    if (dto.doctorId !== undefined) await this.ensureDoctorExists(dto.doctorId);

    const { date, ...rest } = dto;
    Object.assign(appointment, rest);
    if (date) appointment.date = new Date(date);
    // Keep the relation in sync with the foreign key
    if (dto.doctorId !== undefined) delete appointment.doctor;

    await this.appointmentRepo.save(appointment);
    return this.findOne(id);
  }

  async remove(id: number): Promise<{ message: string; id: number }> {
    const appointment = await this.findOne(id);
    await this.appointmentRepo.remove(appointment);
    return { message: 'Appointment deleted', id };
  }
}
