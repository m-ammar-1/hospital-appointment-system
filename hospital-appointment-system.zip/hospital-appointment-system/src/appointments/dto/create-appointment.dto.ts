import { Type } from 'class-transformer';
import {
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';

export class CreateAppointmentDto {
  @IsString()
  @IsNotEmpty({ message: 'Patient name must not be empty' })
  patientName: string;

  @IsDateString({}, { message: 'Date must be a valid date' })
  date: string;

  @IsOptional()
  @IsString()
  reason?: string;

  @Type(() => Number)
  @IsInt({ message: 'doctorId must be a whole number' })
  doctorId: number;
}
