import { IsNotEmpty, IsString } from 'class-validator';

export class CreateDoctorDto {
  @IsString()
  @IsNotEmpty({ message: 'Doctor name must not be empty' })
  name: string;

  @IsString()
  @IsNotEmpty({ message: 'Specialization must not be empty' })
  specialization: string;
}
