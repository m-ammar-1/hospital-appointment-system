import { Injectable, OnModuleInit } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Doctor } from './doctor.entity';
import { CreateDoctorDto } from './dto/create-doctor.dto';

@Injectable()
export class DoctorsService implements OnModuleInit {
  constructor(
    @InjectRepository(Doctor)
    private readonly doctorRepo: Repository<Doctor>,
  ) {}

  // Seed two doctors on first run so the form dropdown is not empty
  async onModuleInit() {
    if ((await this.doctorRepo.count()) === 0) {
      await this.doctorRepo.save([
        { name: 'Dr. Sara Malik', specialization: 'Cardiology' },
        { name: 'Dr. Hamza Ali', specialization: 'General Medicine' },
      ]);
    }
  }

  findAll(): Promise<Doctor[]> {
    return this.doctorRepo.find({ order: { id: 'ASC' } });
  }

  create(dto: CreateDoctorDto): Promise<Doctor> {
    return this.doctorRepo.save(this.doctorRepo.create(dto));
  }
}
